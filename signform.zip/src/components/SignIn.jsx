import React, {useState, useEffect} from "react";
import { NavLink } from "react-router-dom";
import axios from "axios"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
//import {showSuccess} from 'react-toastify'

import './SignIn.css';


function SignIn(){ 

    //const notify = () =>toast("Wow so easy!");

    
   // const [showB, setShowB] = useState(true);
   
  //  const toggleShowB = () => setShowB(!showB);

    //{ showSuccess('Task Submited Successfully', toast);}

    // const [showA, setShowA] = useState(true);
    // const toggleShowA = () => setShowA(!showA);


  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = e => {
      e.preventDefault()
      console.log("Sucessfull");

      let data = JSON.stringify({
         
          "email": email,
          "password": password,
      });

      const config= {
          method: "post",
          url: 'http://192.168.2.194:5000/api/users/signin',
          headers: { 
              'Accept': 'application/json', 
              'Content-Type': 'application/json',
          },
          data: data
      }

      axios(config)
      .then(function (response) {
          console.log('Sign In Sucsessfull', response);

          if (response.data === false) {
              toast.warning(" Please Enter valid data")

          } else {
              console.log(" ");
              toast.success("Successful")

          }
      })
      .catch(function (error) {
          console.log(error.response.data);
          toast.error("Please Enter Valid Data")

      });
  }
    return(
        <div className="container" class="row1"> 

            <h3 class="SignIn">Sign In</h3>

              <div className="form-group mb-4" class="row2">

                            <form class="form" noValidate>

                            <div className="form-group mb-4 row">
                            <label for="uname"><b></b></label>

                            < input type="email"
                            class="text" 
                            placeholder="Email Id"
                            name="email" 
                            onChange={e => setEmail(e.target.value)}
                           
                            required
                            />
                            </div>
                                        
                            <div className="form-group mb-4 row">
                            <label for="form-label"><b></b></label>
                            <input type="password" 
                            class="text" 
                            placeholder="Enter Password" 
                            name="password" 
                            onChange={e => setPassword(e.target.value)}
                            required
                            />
                            </div>

                            <div className="form-group mb-4 row">
                            <button 
                            type="submit" 
                            class="button, far fa-eye" 
                            id="togglePassword"
                            onClick={handleSubmit } 
                           > 
                            Sign In
                            </button>
                            
                            
                            </div>
                           
                            <div className="form-group mb-4 row">  
                            <NavLink to={"/signUp"}>Dont Have An Acount? Sign Up</NavLink>
                            </div>

                            
                            </form>

                           
              </div>  
                             <ToastContainer position="top-end" className="p-3" autoClose={5000} >
                            
                            </ToastContainer>
            
        </div>
        
    );
}

export default SignIn 